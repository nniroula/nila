-- Created by Nila Niroula

\COPY Carrier FROM 'C:\Users\bhim2009\Desktop\Carrier.csv' WITH DELIMITER ',' CSV HEADER;

\COPY Airport_Info FROM 'C:\Users\bhim2009\Desktop\Airport_Info.csv' WITH DELIMITER ',' CSV HEADER;

\COPY Flight_Info FROM 'C:\Users\bhim2009\Desktop\Flight_Info.csv' WITH DELIMITER ',' CSV HEADER;

\COPY States FROM 'C:\Users\bhim2009\Desktop\States.csv' WITH DELIMITER ',' CSV HEADER;

\COPY Extras FROM 'C:\Users\bhim2009\Desktop\Extras.csv' WITH DELIMITER ',' CSV HEADER;

\COPY Cities FROM 'C:\Users\bhim2009\Desktop\Cities.csv' WITH DELIMITER ',' CSV HEADER;