-- Created by Nila Niroua for CS3810 

Create table Carrier( Unique_Carrier_Entity Varchar(100),	
		      Airline_ID INT,	
		      Unique_Carrier_Name Varchar(200),	
		      Unique_Carrier Varchar(10),
		      PRIMARY KEY( Unique_Carrier_Entity)
		    );


Create table Flight_Info( Airline_ID INT,	
		      Passengers INT,	
		      Freights INT,	
		      Distance INT,	
		      Origin_Airport_ID INT,	
		      Dest_Airport_ID INT,	
  		      Carrier_Group INT
		      --PRIMARY KEY( Airline_ID)
		    );                       

Create table Airport_Info( Airport_ID INT,	
		           Airport_Seq_ID INT,	
			   City_Market_ID INT,	
			   Airport Varchar(3),
			   PRIMARY KEY( Airport_ID)
			 );

Create table Cities( City_Name Varchar(100),	
		     City_Market_ID INT,	
		     State_ABR Varchar(2)
		     --PRIMARY KEY( City_Market_ID)
		   ); 

Create table States( State_ABR Varchar(2),	
		     State_Name Varchar(100),	
		     State_WAC INT,	
		     State_Fips INT
		     --PRIMARY KEY( State_Name)
		   );


Create table Extras( Carrier_Group INT,	
		     Departure_Scheduled INT,	
		     Departures_Performed INT,	
		     Payload INT,	
		     Seats INT,	
		     Mail INT,	
		     Ramp_To_Ramp INT,	
		     Air_Time INT,	
		     Region Varchar(50),	
		     Carrier_Ggoup_New INT,	
		     Aircraft_Group INT,	
		     Aircraft_Type INT,	
		     Aircraft_Config INT,	
		     Year INT,	
		     Quarter INT,	
		     Month INT,	
		     Class Varchar(50),	
		     Start_Date_Source date,	
		     Thru_Date_Source date
		     --PRIMARY KEY( Carrier_Group)
		   );

